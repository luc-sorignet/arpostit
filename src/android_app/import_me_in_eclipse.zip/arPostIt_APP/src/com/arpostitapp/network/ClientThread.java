package com.arpostitapp.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

/**
 * 
 * @author Luc SORIGNET
 *
 */
public class ClientThread extends Thread {

	Handler handler;
	String inputLine;
	BufferedReader in;


	public ClientThread(Socket sock, Handler _handler) {
		super("ClientThread");    	
		Log.i("ClientThread", "Create [OK]");
		handler = _handler;
		try {
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		} catch (IOException e) {
			Log.e("ClientThread", "Error : "+e.getMessage());
		}
	}

	
	/**
	 * Run Method: ClientSocket treatment
	 */
	@Override
	public void run() {
		try {
			while ((inputLine = in.readLine()) != null) {		
				// Get tokens
				String[] separated = inputLine.split(NetConfig.endDelimiter);
				// Create a message from incoming info and send it to handler
				//TRAME FORMAT : trash;id;corner;matrix_homografic;
				if (separated.length > 1){
					Message m = new Message();
					Bundle b = new Bundle();
					if(separated[1].equals("armarker")){
						b.putString("type",separated[1] );
						b.putInt("id",Integer.valueOf(separated[2].replace(NetConfig.delimiter, "")));
						b.putStringArray("corner", separated[3].split(NetConfig.delimiter));
						b.putStringArray("homographic", separated[4].split(NetConfig.delimiter));
					}else if(separated[1].equals("listpostit")){
						b.putString("type",separated[1] );	
						b.putStringArray("postits", separated[2].split(NetConfig.delimiter));
					}else if(separated[1].equals("action")){
						b.putString("type",separated[1] );
						b.putString("action", separated[2].replace(NetConfig.delimiter, ""));		
					}
				
					
					for (int i=1; i<separated.length; i++){
						b.putString("val" + i, separated[i]);
						Log.d("ClientThread", "Val " + i + "=" + separated[i]);
					}
					m.setData(b);
					handler.sendMessage(m);
				}
			}
			//in.close();
			//socket.close();

		} catch (IOException e) {
			Log.e("ClientThread", "Error " + e.getMessage());
		}
	}

}
