package com.arpostitapp.network;

public class NetConfig {
	public static int port =1337;
	public static String delimiter ="__:__";
	public static String endDelimiter = "__;__";
}
