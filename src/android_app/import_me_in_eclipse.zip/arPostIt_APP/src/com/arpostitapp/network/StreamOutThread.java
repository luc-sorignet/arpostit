package com.arpostitapp.network;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

import android.os.Handler;
import android.util.Log;

public class StreamOutThread extends Thread{
		Handler handler;
		String inputLine, outputLine= ";";
		PrintWriter out ;
		boolean send = false;
		
		public StreamOutThread(Socket sock, Handler _handler) {
			super("StreamOutThread");    	
			handler = _handler;
			try {

				out = new PrintWriter(sock.getOutputStream(), true);
				Log.i("StreamOutThread","Writer created");
			} catch (IOException e) {
				Log.e("StreamOutThread","Error "+e.getMessage());
			}
		
		}


		public void run() {
			while (true){
				if (send) {
					Log.i("StreamOutThread","Sending :  " + outputLine);
					out.println(outputLine);
					send = false;
				}
				try{
				Thread.sleep(10);
				} catch(Exception e){
					Log.e("StreamOutThread","Exception in Thread Sleeping : " + e);
				}
			}
		}
}

