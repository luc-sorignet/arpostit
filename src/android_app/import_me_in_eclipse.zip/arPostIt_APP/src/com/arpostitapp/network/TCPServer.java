package com.arpostitapp.network;


import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

/**
 * TCP SERVER
 * @author Luc SORIGNET
 * Allow the communication between glass and camera
 */
public class TCPServer extends AsyncTask<Handler, Void, Void>  {
	int port;
	
	ServerSocket serverSocket;
	StreamOutThread sot;
	boolean listening = true;

	@Override
	protected Void doInBackground(Handler... handler) {

		port = NetConfig.port;
		// Create socket server
		System.out.println("Server");
		try {
			serverSocket = new ServerSocket(port);
			  Log.i("TCP Server", "Create Server Success on port : "+port);
		} catch (IOException e) {
			  Log.e("TCP Server", "Create Server Fail on port "+port);
			  Log.e("TCP Server", e.getMessage());
			  System.exit(-1);
		}


		Socket clientSocket = null ;
		// Accept a client for the server
		try {
			clientSocket = serverSocket.accept();
			 Log.i("TCP Server", "Client accepted on port : "+port+" ["+clientSocket.toString()+"]");
		} catch (IOException e) {
			Log.e("TCP Server","Accept Client failed: "+port);
			System.exit(-1);
		}
		

		
	    new ClientThread(clientSocket, handler[0]).start();
	    Log.i("TCP Server", "Creating socket client thread");
	    sot = new StreamOutThread(clientSocket, handler[0]);
	    sot.start();
		return null;
	}

	
	/**
	 * Send Message
	 * @param line to send
	 */
	void send(String line){
		 Log.i("TCP Server", "Socket Send " + line);
		 sot.outputLine = line;
		 sot.send = true;
	}

	

}
