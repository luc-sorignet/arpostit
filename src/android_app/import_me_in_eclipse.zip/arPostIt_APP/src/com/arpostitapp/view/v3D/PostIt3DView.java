package com.arpostitapp.view.v3D;


import com.model.ARMarker;
import com.model.ListAR;

import android.content.Context;
import android.opengl.GLSurfaceView;


public class PostIt3DView extends GLSurfaceView{
	ListAR listAR;

	public PostIt3DView(Context context) {
		super(context);
		
		listAR = new ListAR();
		this.setRenderer(new PostItRenderer());
		//this.setEGLConfigChooser(true);
	}
	public void addARMarker(ARMarker arm){
			listAR.add(arm);		
	}

	

	public boolean isListAREnable(){
		return listAR.isEnable();
	}
}
