package com.arpostitapp.view.v2D;

public class Postit2D {

}
