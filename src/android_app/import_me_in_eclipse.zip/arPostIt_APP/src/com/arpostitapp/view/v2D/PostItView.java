package com.arpostitapp.view.v2D;

import com.model.ARMarker;
import com.model.ListAR;
import com.model.ListPostIt;
import com.model.PostIt;
import com.arpostitapp.R;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.Log;
import android.widget.LinearLayout;

public class PostItView extends LinearLayout {
	ListAR listAR;
	ListPostIt lp;
	Paint p;
	int selected;
	boolean display;
	Bitmap next_b;
	Bitmap prev_b;
	public PostItView(Context context) {
		super(context);
		this.setBackgroundColor(Color.BLACK);
		listAR = new ListAR();
		lp = new ListPostIt();
		p = new Paint();
		selected = 0;
		display=false;
		next_b = BitmapFactory.decodeResource(getResources(), R.drawable.next);
		prev_b = BitmapFactory.decodeResource(getResources(), R.drawable.prev);
	}

	public void addARMarker(ARMarker arm) {
		listAR.add(arm);
	}

	public void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if(display){
			drawPostIt(canvas);
		}
		

	}

	/*
	 * private void drawARMarker(Canvas canvas){ listAR.setEnable(false); for
	 * (int i = 0; i < listAR.size(); i++) { //listAR.get(i).calibMarker();
	 * listAR.get(i).drawMarker(canvas, p); } listAR.clear();
	 * listAR.setEnable(true); }
	 */
	private void drawPostIt(Canvas c) {
		Log.i("NbElement Postit","nb el:"+lp.size());
		c.drawColor(Color.BLACK);
		int firstItem =selected-1;
		int lastItem  =selected+1;
		float scale = 0.5f;
		int block =  (int) (300+(2*290*scale));
		int margin = (960 - block)/2;
		if (!lp.isEmpty()) {
			if(firstItem>=0){
				lp.get(firstItem).draw2D(c, p,new Point(margin, 120),scale);
				//Display Prev Button
				c.drawBitmap(this.prev_b, 0, 540-120, p);
			}
			lp.get(selected).draw2D(c, p,new Point((int) (margin+5+290*scale), 120),1f);
			if(lastItem<lp.size()){
				lp.get(lastItem).draw2D(c, p,new Point((int) (margin+ (300+290*scale)), 120),scale);
			//Display Next Button
				c.drawBitmap(this.next_b, 960-312, 540-120, p);
			}
		}
	}

	public boolean isListAREnable() {
		return listAR.isEnable();
	}

	public void action(String act) {
		if(act.equals("display")){
			display=true;
		}else if(act.equals("nodisplay")){
			display=false;
		}
		else if (act.equals("prev")) {
			selected = (selected > 0) ? selected - 1 : 0;
		} else if (act.equals("next")) {
			selected = (selected < lp.size()-1) ? selected + 1 : lp.size() - 1;
		}
	}

	public void addPostit(PostIt p) {
		// TODO Am�liorer le ADD si liste existe d�j�
		lp.add(p);

	}

	public void clearList() {
		lp.clear();
	}
}
