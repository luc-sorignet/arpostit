package com.arpostitapp.view;


import com.arpostitapp.*;
import com.arpostitapp.network.NetConfig;
import com.arpostitapp.network.TCPServer;
import com.arpostitapp.view.v2D.PostItView;
import com.arpostitapp.view.v3D.PostIt3DView;
import com.model.ARMarker;
import com.model.Matrix4x4f;
import com.model.Point2DF;
import com.model.PostIt;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;



/**
 * Main Activity (MainProgram)
 * @author Luc SORIGNET
 *
 */
@SuppressLint("HandlerLeak") public class MainActivity extends Activity {

	TCPServer serv;
    Handler hand;
    CalibView cv;
    boolean is2Dmode = true;

    PostItView pv;
    PostIt3DView p3dv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
      
        cv = new CalibView(this,this);
        pv = new PostItView(this);
        p3dv = new PostIt3DView(this);
        this.networkInit();
        if(!Calibration.isCalibrate){
        	setContentView(cv);
        } else{
        	if(is2Dmode){
        		setContentView(pv);
        	}else{
        		setContentView(p3dv);
        	}
        }
    }
       
    
    public void showViewPostIt(){
    	setContentView(pv);
    }
  
   
 /**
  * Initializing Network
  */
    private void networkInit(){
    	hand = new Handler(){
			@Override
			public void handleMessage(Message msg) {
				 pv.invalidate();
				 
				 if(msg.getData().getString("type").equals("armarker")){
					 /*GET AR MARKER*/
						int id = msg.getData().getInt("id");
						String [] corner = msg.getData().getStringArray("corner");
						String [] homographic = msg.getData().getStringArray("homographic");		
						Matrix4x4f m = new Matrix4x4f(homographic);
						Point2DF cornersP[] = new Point2DF[4];
						for(int i = 0; i< corner.length;i+=3){
							cornersP[Integer.valueOf(corner[i])]=new Point2DF(Float.valueOf(corner[i+1]),Float.valueOf(corner[i+2]));
						}
						ARMarker marker = new ARMarker(id, cornersP, m);
						Log.i("Handler", marker.toString());
						 if(!Calibration.isCalibrate){
								cv.setArMarker(marker);
						 }	
					     else{
					    	if(pv.isListAREnable())
					    	  pv.addARMarker(marker);  	
					    	 
					     }
				 }else if(msg.getData().getString("type").equals("listpostit")){
					 /*GET POSTIT*/
					 pv.clearList();
					 String [] postits = msg.getData().getStringArray("postits");
					 
					 for(int i=0; i<postits.length;i+=3){
						
						 PostIt p = new PostIt(postits[i],postits[i+1],Color.parseColor(postits[i+2]));
						 pv.addPostit(p);
						 Log.i("PostitADD", p.toString()+" COLOR passed :"+ postits[i+2]);
					 }	
						 
					 
				 }else if(msg.getData().getString("type").equals("action")){
					 pv.action(msg.getData().getString("action"));
				 }
			}	
    	};
    	serv = new TCPServer();
    	serv.execute(hand,null,null);
    }
       

}
