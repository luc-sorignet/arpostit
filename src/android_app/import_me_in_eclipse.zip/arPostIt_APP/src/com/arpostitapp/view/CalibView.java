package com.arpostitapp.view;

import com.arpostitapp.Calibration;
import com.arpostitapp.R;
import com.model.ARMarker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * 
 * @author Luc SORIGNET
 *
 */
@SuppressLint("ViewConstructor") 
public class CalibView extends LinearLayout {
	Button btncalib;
	MainActivity activity;
	ARMarker ar;
	Drawable bg;
	
	public CalibView(Context context,MainActivity act) {
		super(context);
		activity = act;	
		this.setVisibility(VISIBLE);
		init();
	}
	private void init() {
		
		inflate(getContext(), R.layout.ui_calib, this);
		btncalib = (Button) findViewById(R.id.btn_calib);
		btncalib.setOnClickListener(new OnClickListener() {
			int step=1 ;
			@Override
			public void onClick(View v) {
				// Calibration	
				LinearLayout p =((LinearLayout)v.getParent());
				if(ar!=null){
					if( step == 1){
						
						Calibration.tl.x=ar.getCorners()[2].x;
						Calibration.tl.y=ar.getCorners()[2].y;
						step++;
						p.setBackgroundResource(R.drawable.calib_br);
					}else{
						Calibration.br.x=ar.getCorners()[0].x;
						Calibration.br.y=ar.getCorners()[0].y;
						Calibration.x = (int)Calibration.br.x/Calibration.GL_WIDTH;
						Calibration.y = (int)Calibration.br.y/Calibration.GL_HEIGHT;
						Calibration.isCalibrate=true;
						activity.showViewPostIt();
						Log.i("Calibration","Calibration OK : "+Calibration.getInfo());
					}
	
				}else{
					Log.d("Calibration","Warning : AR marker Null please check the TCPClient");
				}
			}
		});
	
	}
	
	
	public void setArMarker(ARMarker arm){
		ar = arm;
	}

}
