package com.arpostitapp.view.v3D;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.GLU;
import android.opengl.Matrix;

public class PostItRenderer implements Renderer {

	
	/** Postit instance */
	private Postit3D postit;
	float[] mViewMatrix = new float[16],mMVPMatrix= new float[16],mModelMatrix= new float[16];
	public PostItRenderer(){
		postit = new Postit3D();
	}
	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		
		// Set the background clear color to gray.
	    GLES20.glClearColor(0f, 0f, 0f, 1f);
	    GLES20.glClearDepthf(1f);
	    GLES20.glEnable(GL10.GL_DEPTH_TEST);
	    // Position the eye behind the origin.
	    final float eyeX = 0.0f;
	    final float eyeY = 0.0f;
	    final float eyeZ = -1.5f;
	 
	    // We are looking toward the distance
	    final float lookX = 0.0f;
	    final float lookY = 0.0f;
	    final float lookZ = 1f;
	 
	    // Set our up vector. This is where our head would be pointing were we holding the camera.
	    final float upX = 0.0f;
	    final float upY = 1.0f;
	    final float upZ = 0.0f;
	 
	    // Set the view matrix. This matrix can be said to represent the camera position.
	    // NOTE: In OpenGL 1, a ModelView matrix is used, which is a combination of a model and
	    // view matrix. In OpenGL 2, we can keep track of these matrices separately if we choose.
	    Matrix.setIdentityM(mModelMatrix, 0);
	    Matrix.setLookAtM(mViewMatrix, 0, eyeX, eyeY, eyeZ, lookX, lookY, lookZ, upX, upY, upZ);
	    Matrix.multiplyMM(mMVPMatrix, 0, mViewMatrix, 0, mModelMatrix, 0);
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		
	}

	@Override
	public void onDrawFrame(GL10 gl) {
		gl.glPushMatrix();
		gl.glLoadMatrixf(mMVPMatrix, 0);
		postit.draw(gl);
		gl.glPopMatrix();
		
	}

}
