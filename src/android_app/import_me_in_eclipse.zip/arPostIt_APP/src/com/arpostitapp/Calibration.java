package com.arpostitapp;

import com.model.Point2DF;

/**
 * Class Calibration
 * Define different informations about
 * the Epson Resolution and calibration
 * camera.
 * @author sorignet
 * 
 * 
 */
public class Calibration {
	//X CAM : 260px
	//Y CAM : 240px
	public static final int GL_WIDTH = 960;
	public static final int GL_HEIGHT = 540;
	public static final int C_UNIT = 256;

	//public static ARMarker am=null;
	public static Point2DF tl = new Point2DF(0, 0); 
	public static Point2DF br = new Point2DF(0, 0); 
	public static int x=0;
	public static int y=0;
	public static boolean isCalibrate = true;
	public static String getInfo(){
		return "Calibration : br "+br.toString()+ " tl "+tl.toString()+" xratio = "+x+" yratio = "+y+" \n";
	}
}
