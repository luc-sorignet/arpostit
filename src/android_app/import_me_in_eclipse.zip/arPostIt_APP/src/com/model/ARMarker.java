package com.model;

import com.arpostitapp.Calibration;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;


/**
 * 
 * @author sorignet
 *
 * ARMarker Corner Disposition
 * 2 +----+ 1
 *   |    |
 *   |    |
 * 3 +----+ 0
 */
public class ARMarker {
	 private int id;
	 private Point2DF corners[];
	 private Matrix4x4f homographic;
	 private Point2DF gc;
	 public ARMarker(int id,Point2DF[] corners,Matrix4x4f homographic){
		 this.id=id;
		 this.corners=corners;
		 this.gc = new Point2DF(0, 0);
		 for(int i=0;i<4;i++){
			 
			 this.gc.x+=this.corners[i].x;
			 this.gc.y+=this.corners[i].y;
		 }
		 this.gc.x/=4;
		 this.gc.y/=4;
		 this.homographic=homographic;
	 }
	 public ARMarker(ARMarker ar){
		 this.id=ar.id;
		 this.corners=new Point2DF[4];
		 this.gc = new Point2DF(0, 0);
		 for(int i=0;i<4;i++){
			 this.corners[i] = new Point2DF(ar.corners[i].x,ar.corners[i].y);
			 this.gc.x+=ar.corners[i].x;
			 this.gc.y+=ar.corners[i].y;
		 }
		 this.gc.x/=4;
		 this.gc.y/=4;
		 this.homographic = new Matrix4x4f(ar.homographic);
	 }
	 
	 public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Point2DF[] getCorners() {
		return corners;
	}

	public void setCorners(Point2DF[] corners) {
		this.corners = corners;
	}

	public Matrix4x4f getHomographic() {
		return homographic;
	}

	public void setHomographic(Matrix4x4f homographic) {
		this.homographic = homographic;
	}
	public void calibMarker(){
		for(int i=0;i<4;i++){
			 this.corners[i].x *=Calibration.x;
			 this.corners[i].y *=Calibration.y;
			
		 }
	}
	public void drawMarker(Canvas c,Paint p){
		
		p.setColor(Color.YELLOW);
		
		c.drawLine(corners[0].x, corners[0].y, corners[1].x, corners[1].y, p);
		c.drawLine(corners[0].x, corners[0].y, corners[3].x, corners[3].y, p);
		c.drawLine(corners[2].x, corners[2].y, corners[1].x, corners[1].y, p);
		c.drawLine(corners[2].x, corners[2].y, corners[3].x, corners[3].y, p);
		
		p.setColor(Color.GREEN);
		p.setTextSize(20);
		c.drawText(""+this.id, this.gc.x, this.gc.y, p);
		c.drawPoint(this.gc.x,  this.gc.y, p);
		p.setColor(Color.BLUE);
		float x= homographic.getCenter3D().x/homographic.getCenter3D().z;
		float y= homographic.getCenter3D().y/homographic.getCenter3D().z;
		Log.i("point3D/2D","x="+x+" y="+y+" R2Dx="+this.gc.x+" R2Dy"+this.gc.y);
		c.drawPoint(x, y, p);
		p.setColor(Color.RED);
		p.setStrokeWidth(4);
		for(int i=0;i<corners.length;i++){
			c.drawPoint(corners[i].x, corners[i].y, p);
		}
	}
	 public String toString(){
		 String str="MARKER ID :"+id+"\nCORNERS:\n";
		 for (int i = 0; i<4; i++){
			 str+=corners[i]+"\n";
		 }
		 str+="HOMOGRAPHIC MATRIX \n"+homographic.toString();
		 return str;
	 }
}
