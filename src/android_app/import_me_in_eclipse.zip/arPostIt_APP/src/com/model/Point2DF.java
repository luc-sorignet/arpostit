package com.model;

public class Point2DF {
	public float x;
	public float y;
	
	public Point2DF (float x,float y){
		this.x=x;
		this.y=y;
	}
	public Point2DF (Point2DF p){
		this.x=new Float(p.x);
		this.y=new Float(p.y);
	}
	
	public float getDistance(float x, float y){
		return (float) Math.sqrt(Math.pow((this.x-x),2)+Math.pow((this.y-y),2));
	}
	
	public String toString(){
		return "[ "+x+" "+y+" ]";
	}
	
}
