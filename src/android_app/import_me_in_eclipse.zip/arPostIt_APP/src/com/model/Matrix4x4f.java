package com.model;

/**
 * Float Matrix 4x4 
 * @author Luc SORIGNET
 *
 */
public class Matrix4x4f {
	private float mat[][];
	
	public Matrix4x4f(String[] homographic){
		mat = new float[4][4];
		String[] s = homographic;
		int j=0 ,k=0;
		for(int i=0;i<s.length;i++){
			/* Matrix  Filling */ 
			mat[j][k] = Float.valueOf(s[i]);
			j++;
			//If end of line
			if(j%4==0){
				j%=4;
				k++;
			}
		}
	}
	
	public Matrix4x4f(Matrix4x4f m){
		mat = new float[4][4];
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				this.mat[i][j]=m.mat[i][j];
			}
		}
	}
	public Point3d getCenter3D(){
		return new Point3d(mat[3][0], mat[3][1], mat[3][2]);
	}
	
	public String toString(){
		String str="";
		str += "[ " + mat[0][0] + " "+mat[1][0] + " "+mat[2][0] + " "+mat[3][0] + " ]\n";
		str += "[ " + mat[0][1] + " "+mat[1][1] + " "+mat[2][1] + " "+mat[3][1] + " ]\n";
		str += "[ " + mat[0][2] + " "+mat[1][2] + " "+mat[2][2] + " "+mat[3][2] + " ]\n";
		str += "[ " + mat[0][3] + " "+mat[1][3] + " "+mat[2][3] + " "+mat[3][3] + " ]\n";
		return str;
		
	}
}
