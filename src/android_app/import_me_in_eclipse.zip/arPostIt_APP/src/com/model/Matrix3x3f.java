package com.model;

/**
 * Float Matrix 4x4 
 * @author Luc SORIGNET
 *
 */
public class Matrix3x3f {
	private float mat[][];
	
	public Matrix3x3f(String strMat){
		mat = new float[3][3];
		String[] s = strMat.split(":");
		int j=0 ,k=0;
		for(int i=0;i<s.length;i++){
			/* Matrix  Filling */ 
			mat[j][k] = Float.valueOf(s[i]);
			j++;
			//If end of line
			if(j%4==0){
				j%=4;
				k++;
			}
		}
	}
	
	public Matrix3x3f(Matrix3x3f m){
		mat = new float[3][3];
		for(int i=0;i<4;i++){
			for(int j=0;j<4;j++){
				this.mat[i][j]=m.mat[i][j];
			}
		}
	}
	public Point3d getCenter3D(){
		return new Point3d(mat[3][0], mat[3][1], mat[3][2]);
	}
	
	public String toString(){
		String str="";
		str += "[ " + mat[0][0] + " "+mat[1][0] + " "+mat[2][0] + " ]\n";
		str += "[ " + mat[0][1] + " "+mat[1][1] + " "+mat[2][1] + " ]\n";
		str += "[ " + mat[0][2] + " "+mat[1][2] + " "+mat[2][2] + " ]\n";
		
		return str;
		
	}
}
