package com.model;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Align;
import android.graphics.Point;
import android.graphics.Typeface;
import android.util.Log;
import android.view.View.MeasureSpec;
import android.widget.TextView;

/**
 * Classe PostIT
 * 
 * @author Luc SORIGNET
 * 
 */
public class PostIt {
	private String title;
	private String content;
	private int color;
	private Typeface tfT;
	private Typeface tfC;

	// private String date;
	/**
	 * Constructor
	 * 
	 * @param id
	 *            Postit
	 * @param content
	 *            Postit
	 */
	public PostIt(String title, String content, int color, Typeface tfTitle,
			Typeface tfContent) {
		this.title = title;
		this.content = content;
		this.color = color;
		tfT = tfTitle;
		tfC = tfContent;
	}

	public PostIt(String title, String content, int color) {
		this(title, content, color,
				Typeface.create("Helvetica", Typeface.BOLD), Typeface.create(
						"monospace", Typeface.NORMAL));
	}

	public PostIt(String title, String content) {
		this(title, content, Color.YELLOW);
	}

	public PostIt() {
		this("", "");
	}

	// GETTER AND SETTER
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getTitle() {
		return title;
	}

	public void getTitle(String title) {
		this.title = title;
	}

	public void draw2D(Canvas c, Paint p, Point pos, float scale) {
			p.setColor(this.color);
			c.drawRect(pos.x, pos.y, pos.x + 290*scale, pos.y + 290*scale, p);
			p.setColor(Color.BLACK);
			p.setTextSize(20*scale);
			p.setTypeface(tfT);
			p.setTextAlign(Align.CENTER);
			c.drawText(this.title, pos.x + (290*scale / 2), pos.y + 20*scale, p);
			p.setTypeface(tfC);
			p.setTextAlign(Align.LEFT);
			c.drawText(this.content, pos.x + 5*scale, pos.y + 50*scale, p);
		}

	public void draw2D(Canvas c, Paint p, Point pos, float scale,boolean selected) {
		this.draw2D(c,p,pos,scale);
		if (selected) {
			float oldstroke = p.getStrokeWidth();
			float stroke = 4; // Max 5
			p.setColor(Color.RED);
			p.setStrokeWidth(stroke*scale);
			c.drawLine(pos.x - stroke*scale, pos.y - stroke*scale, pos.x + 290*scale + stroke*scale,
					pos.y - stroke, p);
			c.drawLine(pos.x - stroke*scale, pos.y + 290*scale + stroke*scale, pos.x + 290*scale
					+ stroke*scale, pos.y + 290*scale + stroke*scale, p);
			c.drawLine(pos.x - stroke*scale, pos.y - stroke*scale, pos.x - stroke*scale, pos.y
					+ 290*scale + stroke*scale, p);
			c.drawLine(pos.x + 290 + stroke*scale, pos.y - stroke*scale, pos.x + 290*scale
					+ stroke*scale, pos.y + 290*scale + stroke*scale, p);
			p.setStrokeWidth(oldstroke);
		}

	}

	public void draw3D() {
	}

}
