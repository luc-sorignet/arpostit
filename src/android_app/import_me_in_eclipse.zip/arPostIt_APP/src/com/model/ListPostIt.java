package com.model;

import java.util.ArrayList;

/**
 * ListPostIt
 * Array List of Postit with � 3D Position
 * @author sorignet
 *
 */
public class ListPostIt extends ArrayList <PostIt> {


}
