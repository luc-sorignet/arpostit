package com.model;

import java.util.ArrayList;



public class ListAR extends ArrayList <ARMarker> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean enable;
	public ListAR(){
		super();
		enable =true;
	}
	
	
	
	public boolean contains(ARMarker arm){
		boolean exist = false;
		for(ARMarker a :this){
			if(a.getId()==arm.getId()){
				exist=true;
			}
		}
		return exist;
	}
	
	public boolean add(ARMarker arm){
		if(!this.contains(arm)){
			super.add(arm);
		}
		else{
			int i=0;
			while(i<this.size()&&this.get(i).getId()!=arm.getId()){
				i++;
			}
			this.set(i,arm);
		}
			
		return true;
	}
	
	public void setEnable(boolean value){
		enable = value;
	}
	
	public boolean isEnable(){
		return enable;
	}
}
