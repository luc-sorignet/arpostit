package com.model;

public class Point3d {
	public float x;
	public float y;
	public float z;
	
	public Point3d (float x, float y, float z){
		this.x=x;this.y=y;this.z=z;
	}
	
	public Point3d(Point3d p){
		this.x=p.x;this.y=p.y;this.z=p.z;
	}
}
